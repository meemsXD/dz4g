/*
Автор: Смыков В.А.
Семинар 1. Анализ результатов квалификации гоночных болидов.
Запуск из папки проекта: dotnet run
Для проверки тестовыми данными введите количество участников 0.
*/

using System.Globalization;
using System.Text;

internal static class Program
{
    private static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.InputEncoding = Encoding.UTF8;
        CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;
        CultureInfo.CurrentUICulture = CultureInfo.InvariantCulture;

        Console.WriteLine("=== АНАЛИЗ КВАЛИФИКАЦИИ ГРАН-ПРИ ===");
        Console.WriteLine("Введите 0, чтобы использовать тестовые данные из задания.");
        Console.WriteLine();

        int participantCount = ReadNonNegativeInt("Введите количество участников: ");
        if (participantCount == 0)
        {
            string[] testTeams =
            {
                "Red Bull Racing", "Ferrari", "Mercedes", "McLaren", "Alpine",
                "Aston Martin", "AlphaTauri", "Alfa Romeo", "Haas", "Williams"
            };
            double[] testSpeeds = { 228.5, 226.3, 224.8, 223.7, 221.4, 220.9, 219.6, 218.2, 216.5, 215.1 };
            RunQualificationAnalysis(testTeams, testSpeeds, testTeams.Length);
            return;
        }

        string[] teams = new string[participantCount];
        double[] avgSpeeds = new double[participantCount];

        InputData(teams, avgSpeeds, participantCount);
        RunQualificationAnalysis(teams, avgSpeeds, participantCount);
    }

    private static void InputData(string[] teams, double[] speeds, int count)
    {
        for (int i = 0; i < count; i++)
        {
            Console.WriteLine($"Участник #{i + 1}");
            teams[i] = ReadRequiredString("Команда: ");
            speeds[i] = ReadDouble("Средняя скорость (км/ч): ");
            Console.WriteLine();
        }
    }

    private static void RunQualificationAnalysis(string[] teams, double[] speeds, int count)
    {
        Console.WriteLine();
        Console.WriteLine("--- СТАТИСТИКА КВАЛИФИКАЦИИ ---");
        CalculateStatistics(teams, speeds, count);

        Console.WriteLine();
        Console.WriteLine("--- ИСХОДНЫЙ ПОРЯДОК ---");
        PrintTable(teams, speeds, count, withPositions: false);

        string[] sortedTeams = new string[count];
        double[] sortedSpeeds = new double[count];
        CopyArrays(teams, speeds, sortedTeams, sortedSpeeds, count);

        BubbleSort(sortedTeams, sortedSpeeds, count);

        Console.WriteLine();
        Console.WriteLine("--- ИТОГОВЫЙ ПРОТОКОЛ КВАЛИФИКАЦИИ ---");
        Console.WriteLine("Алгоритм сортировки: пузырьковая сортировка по убыванию скорости.");
        PrintTable(sortedTeams, sortedSpeeds, count, withPositions: true);

        Console.WriteLine();
        FilterBySpeed(sortedTeams, sortedSpeeds, count);
    }

    private static void CalculateStatistics(string[] teams, double[] speeds, int count)
    {
        if (count <= 0)
        {
            Console.WriteLine("Нет участников для анализа.");
            return;
        }

        double sum = 0;
        for (int i = 0; i < count; i++)
            sum += speeds[i];

        double average = sum / count;
        double maxSpeed = speeds[0];
        double minSpeed = speeds[0];
        string fastestTeam = teams[0];
        string slowestTeam = teams[0];

        for (int i = 1; i < count; i++)
        {
            if (speeds[i] > maxSpeed)
            {
                maxSpeed = speeds[i];
                fastestTeam = teams[i];
            }

            if (speeds[i] < minSpeed)
            {
                minSpeed = speeds[i];
                slowestTeam = teams[i];
            }
        }

        Console.WriteLine($"Средняя скорость: {average:F2} км/ч");
        Console.WriteLine($"Лидер: {fastestTeam} ({maxSpeed:F2} км/ч)");
        Console.WriteLine($"Самый медленный: {slowestTeam} ({minSpeed:F2} км/ч)");
        Console.WriteLine($"Разница темпа: {maxSpeed - minSpeed:F2} км/ч");
    }

    private static void PrintTable(string[] teams, double[] speeds, int count, bool withPositions)
    {
        if (withPositions)
        {
            Console.WriteLine("------------------------------------------------------------");
            Console.WriteLine($"| {"Поз.",4} | {"Команда",-25} | {"Скорость",12} |");
            Console.WriteLine("------------------------------------------------------------");
            for (int i = 0; i < count; i++)
                Console.WriteLine($"| {i + 1,4} | {teams[i],-25} | {speeds[i],12:F2} |");
            Console.WriteLine("------------------------------------------------------------");
        }
        else
        {
            Console.WriteLine("------------------------------------------------");
            Console.WriteLine($"| {"Команда",-25} | {"Скорость (км/ч)",15} |");
            Console.WriteLine("------------------------------------------------");
            for (int i = 0; i < count; i++)
                Console.WriteLine($"| {teams[i],-25} | {speeds[i],15:F2} |");
            Console.WriteLine("------------------------------------------------");
        }
    }

    private static void CopyArrays(string[] sourceTeams, double[] sourceSpeeds, string[] targetTeams, double[] targetSpeeds, int count)
    {
        for (int i = 0; i < count; i++)
        {
            targetTeams[i] = sourceTeams[i];
            targetSpeeds[i] = sourceSpeeds[i];
        }
    }

    private static void BubbleSort(string[] teams, double[] speeds, int count)
    {
        for (int i = 0; i < count - 1; i++)
        {
            for (int j = 0; j < count - i - 1; j++)
            {
                if (speeds[j] < speeds[j + 1])
                {
                    double tempSpeed = speeds[j];
                    speeds[j] = speeds[j + 1];
                    speeds[j + 1] = tempSpeed;

                    string tempTeam = teams[j];
                    teams[j] = teams[j + 1];
                    teams[j + 1] = tempTeam;
                }
            }
        }
    }

    private static void FilterBySpeed(string[] teams, double[] speeds, int count)
    {
        double minimumSpeed = ReadDouble("Введите минимальную скорость для отбора (км/ч): ");
        int selectedCount = 0;

        Console.WriteLine($"Команды со скоростью >= {minimumSpeed:F2} км/ч:");
        for (int i = 0; i < count; i++)
        {
            if (speeds[i] >= minimumSpeed)
            {
                Console.WriteLine($"- {teams[i]} ({speeds[i]:F2} км/ч)");
                selectedCount++;
            }
        }

        Console.WriteLine($"Отобрано команд: {selectedCount}");
    }

    private static int ReadNonNegativeInt(string prompt)
    {
        while (true)
        {
            int value = ReadInt(prompt);
            if (value >= 0)
                return value;
            Console.WriteLine("Ошибка: число не может быть отрицательным.");
        }
    }

    private static int ReadInt(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            string text = Console.ReadLine()?.Trim() ?? string.Empty;
            if (int.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out int value))
                return value;
            Console.WriteLine("Ошибка: введите целое число.");
        }
    }

    private static double ReadDouble(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            string text = (Console.ReadLine()?.Trim() ?? string.Empty).Replace(',', '.');
            if (double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out double value))
                return value;
            Console.WriteLine("Ошибка: введите вещественное число.");
        }
    }

    private static string ReadRequiredString(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            string text = Console.ReadLine() ?? string.Empty;
            if (!string.IsNullOrWhiteSpace(text))
                return text.Trim();
            Console.WriteLine("Ошибка: строка не должна быть пустой.");
        }
    }
}
