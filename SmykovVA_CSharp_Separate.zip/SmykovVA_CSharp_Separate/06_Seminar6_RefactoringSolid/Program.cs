/*
Автор: Смыков В.А.
Семинар 6. Рефакторинг и принципы SOLID.
Запуск из папки проекта: dotnet run
*/

using System.Text;

internal static class Program
{
    private static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;

        Console.WriteLine("=== СЕМИНАР 6. РЕФАКТОРИНГ И SOLID ===");
        PrintDetectedViolations();
        RunRefactoredLibraryServiceDemo();
        RunFineStrategyDemo();
    }

    private static void PrintDetectedViolations()
    {
        Console.WriteLine("\nНарушения в исходном LibraryService:");
        Console.WriteLine("- SRP: один класс хранит данные, валидирует, логирует и создаёт отчёты.");
        Console.WriteLine("- DRY: проверка пустого названия повторяется в AddBook и AddMagazine.");
        Console.WriteLine("- OCP: при добавлении нового типа элемента пришлось бы менять PrintReport.");
        Console.WriteLine("- DIP: класс напрямую зависит от File и Console, а не от абстракций.");
        Console.WriteLine("- KISS: используется reflection и List<object> вместо нормальной модели предметной области.");
    }

    private static void RunRefactoredLibraryServiceDemo()
    {
        Console.WriteLine("\nРефакторинг LibraryService:");
        LibraryItemValidator validator = new LibraryItemValidator();
        ILibraryLogWriter logWriter = new FileLibraryLogWriter(Path.Combine(AppContext.BaseDirectory, "library.log"));
        ILibraryReportWriter reportWriter = new FileLibraryReportWriter(Path.Combine(AppContext.BaseDirectory, "report.txt"));
        RefactoredLibraryService service = new RefactoredLibraryService(validator, logWriter, reportWriter);

        service.AddBook("Евгений Онегин", "Пушкин", 1833);
        service.AddMagazine("Наука и жизнь", 5);
        service.AddBook("Война и мир", "Толстой", 1869);
        service.PrintReport();
        service.SaveReport();

        Console.WriteLine("\nПрименённые приёмы:");
        Console.WriteLine("- Extract Class: выделены LibraryItem, BookItem, MagazineItem, Validator, LogWriter, ReportWriter.");
        Console.WriteLine("- Extract Method: общая проверка названия вынесена в ValidateTitle.");
        Console.WriteLine("- Replace Type Code with Subclasses: вместо Type/anonymous object используются наследники LibraryItem.");
        Console.WriteLine("- Dependency Injection: логгер и сохранение отчёта передаются через конструктор.");
    }

    private static void RunFineStrategyDemo()
    {
        Console.WriteLine("\nПаттерн Strategy через принципы SOLID:");
        FineRule rule = GetFineRuleFor("Senior");
        FineCalculator calculator = new FineCalculator(rule);
        decimal fine = calculator.Calculate(daysOverdue: 10);
        Console.WriteLine($"Категория Senior, просрочка 10 дней, штраф: {fine} руб.");
    }

    private static FineRule GetFineRuleFor(string readerCategory)
    {
        return readerCategory switch
        {
            "Regular" => new RegularFineRule(),
            "Student" => new StudentFineRule(),
            "Senior" => new SeniorFineRule(),
            "Staff" => new StaffFineRule(),
            _ => throw new ArgumentException("Неизвестная категория читателя")
        };
    }
}

internal abstract class LibraryItem
{
    public string Title { get; }

    protected LibraryItem(string title)
    {
        Title = title;
    }

    public abstract string GetReportLine();
}

internal sealed class BookItem : LibraryItem
{
    public string Author { get; }
    public int Year { get; }

    public BookItem(string title, string author, int year) : base(title)
    {
        Author = author;
        Year = year;
    }

    public override string GetReportLine()
    {
        return $"Книга: {Title}, автор: {Author}, год: {Year}";
    }
}

internal sealed class MagazineItem : LibraryItem
{
    public int IssueNumber { get; }

    public MagazineItem(string title, int issueNumber) : base(title)
    {
        IssueNumber = issueNumber;
    }

    public override string GetReportLine()
    {
        return $"Журнал: {Title}, выпуск №{IssueNumber}";
    }
}

internal sealed class LibraryItemValidator
{
    public void ValidateTitle(string title)
    {
        if (string.IsNullOrWhiteSpace(title))
            throw new ArgumentException("Название не может быть пустым.");
    }

    public void ValidateBook(string title, string author, int year)
    {
        ValidateTitle(title);
        if (string.IsNullOrWhiteSpace(author))
            throw new ArgumentException("Автор не может быть пустым.");
        if (year < 1000 || year > DateTime.Now.Year)
            throw new ArgumentException("Некорректный год издания.");
    }

    public void ValidateMagazine(string title, int issueNumber)
    {
        ValidateTitle(title);
        if (issueNumber <= 0)
            throw new ArgumentException("Номер выпуска должен быть положительным.");
    }
}

internal interface ILibraryLogWriter
{
    void Write(string message);
}

internal sealed class FileLibraryLogWriter : ILibraryLogWriter
{
    private readonly string _path;

    public FileLibraryLogWriter(string path)
    {
        _path = path;
    }

    public void Write(string message)
    {
        File.AppendAllText(_path, $"{DateTime.Now:u}: {message}{Environment.NewLine}", Encoding.UTF8);
    }
}

internal interface ILibraryReportWriter
{
    void Write(string reportText);
}

internal sealed class FileLibraryReportWriter : ILibraryReportWriter
{
    private readonly string _path;

    public FileLibraryReportWriter(string path)
    {
        _path = path;
    }

    public void Write(string reportText)
    {
        File.WriteAllText(_path, reportText, Encoding.UTF8);
        Console.WriteLine($"Отчёт сохранён: {_path}");
    }
}

internal sealed class RefactoredLibraryService
{
    private readonly List<LibraryItem> _items = new List<LibraryItem>();
    private readonly LibraryItemValidator _validator;
    private readonly ILibraryLogWriter _logWriter;
    private readonly ILibraryReportWriter _reportWriter;

    public RefactoredLibraryService(LibraryItemValidator validator, ILibraryLogWriter logWriter, ILibraryReportWriter reportWriter)
    {
        _validator = validator;
        _logWriter = logWriter;
        _reportWriter = reportWriter;
    }

    public void AddBook(string title, string author, int year)
    {
        _validator.ValidateBook(title, author, year);
        _items.Add(new BookItem(title, author, year));
        _logWriter.Write($"Добавлена книга «{title}»");
    }

    public void AddMagazine(string title, int issueNumber)
    {
        _validator.ValidateMagazine(title, issueNumber);
        _items.Add(new MagazineItem(title, issueNumber));
        _logWriter.Write($"Добавлен журнал «{title}»");
    }

    public string BuildReport()
    {
        StringBuilder builder = new StringBuilder();
        builder.AppendLine($"=== Отчёт: {_items.Count} элементов ===");
        for (int i = 0; i < _items.Count; i++)
            builder.AppendLine(_items[i].GetReportLine());
        builder.AppendLine($"Дата: {DateTime.Now:u}");
        return builder.ToString();
    }

    public void PrintReport()
    {
        Console.WriteLine(BuildReport());
    }

    public void SaveReport()
    {
        _reportWriter.Write(BuildReport());
    }
}

internal abstract class FineRule
{
    public abstract decimal Calculate(int daysOverdue);
}

internal sealed class RegularFineRule : FineRule
{
    public override decimal Calculate(int daysOverdue)
    {
        return Math.Max(0, daysOverdue) * 5m;
    }
}

internal sealed class StudentFineRule : FineRule
{
    public override decimal Calculate(int daysOverdue)
    {
        return Math.Max(0, daysOverdue - 3) * 2m;
    }
}

internal sealed class SeniorFineRule : FineRule
{
    public override decimal Calculate(int daysOverdue)
    {
        return Math.Max(0, daysOverdue - 7) * 3m;
    }
}

internal sealed class StaffFineRule : FineRule
{
    public override decimal Calculate(int daysOverdue)
    {
        return 0m;
    }
}

internal sealed class FineCalculator
{
    private readonly FineRule _rule;

    public FineCalculator(FineRule rule)
    {
        _rule = rule;
    }

    public decimal Calculate(int daysOverdue)
    {
        return _rule.Calculate(daysOverdue);
    }
}
