/*
Автор: Смыков В.А.
Семинар 5. Внедрение зависимостей.
Запуск из папки проекта: dotnet run
*/

using System.Text;
using Microsoft.Extensions.DependencyInjection;

internal static class Program
{
    private static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;

        Console.WriteLine("=== СЕМИНАР 5. ВНЕДРЕНИЕ ЗАВИСИМОСТЕЙ ===");

        RunPureDiDemo();
        RunContainerDemo();
        PrintControlTaskAnswer();
    }

    private static void RunPureDiDemo()
    {
        Console.WriteLine("\n1) Pure DI и внедрение через конструктор:");
        ILogger logger = new ConsoleLogger();
        IBookStorage storage = new InMemoryBookStorage(logger);
        BookCatalogService service = new BookCatalogService(storage, logger);
        service.AddBook("Евгений Онегин", "Пушкин");
        service.RemoveBook("Евгений Онегин");

        Console.WriteLine("\n2) Внедрение через свойство:");
        BookCatalogServiceWithProperty propertyService = new BookCatalogServiceWithProperty();
        propertyService.AddBook("Тихий режим", "Автор");
        propertyService.Logger = logger;
        propertyService.AddBook("Сборник стихотворений", "Пушкин");

        Console.WriteLine("\n3) Внедрение через параметр метода:");
        BookCatalogServiceWithMethod methodService = new BookCatalogServiceWithMethod();
        methodService.AddBook("Книга с консольным логгером", "Автор", logger);
        methodService.AddBook("Книга с файловым логгером", "Автор", new FileLogger(Path.Combine(AppContext.BaseDirectory, "audit.log")));
    }

    private static void RunContainerDemo()
    {
        Console.WriteLine("\n4) DI-контейнер Microsoft.Extensions.DependencyInjection:");
        ServiceCollection services = new ServiceCollection();
        services.AddSingleton<ILogger, ConsoleLogger>();
        services.AddSingleton<IBookStorage, InMemoryBookStorage>();
        services.AddTransient<BookCatalogService>();

        using ServiceProvider provider = services.BuildServiceProvider(
            new ServiceProviderOptions { ValidateOnBuild = true, ValidateScopes = true });

        BookCatalogService service = provider.GetRequiredService<BookCatalogService>();
        service.AddBook("Архитектура программных систем", "Смыков В.А.");
    }

    private static void PrintControlTaskAnswer()
    {
        Console.WriteLine("\n5) Контрольное задание: найденные антипаттерны и исправление");
        Console.WriteLine("- new InMemoryBookStorage(new ConsoleLogger()) внутри конструктора — Control Freak.");
        Console.WriteLine("- Конструктор без параметров вместе с DI-конструктором — Bastard Injection.");
        Console.WriteLine("- AppServices.Get<ILogger>() внутри метода — Service Locator.");
        Console.WriteLine("- CurrentLogger.Instance внутри метода — Ambient Context.");
        Console.WriteLine("Исправление: зависимости IBookStorage и ILogger явно передаются через конструктор BookCatalogService.");

        ILogger logger = new ConsoleLogger();
        IBookStorage storage = new InMemoryBookStorage(logger);
        BookCatalogService corrected = new BookCatalogService(storage, logger);
        corrected.AddBook("Исправленный сервис", "Смыков В.А.");
        corrected.RemoveBook("Исправленный сервис");
    }
}

internal interface ILogger
{
    void Log(string message);
}

internal sealed class ConsoleLogger : ILogger
{
    public void Log(string message)
    {
        Console.WriteLine($"[LOG] {message}");
    }
}

internal sealed class FileLogger : ILogger
{
    private readonly string _filePath;

    public FileLogger(string filePath)
    {
        _filePath = filePath;
    }

    public void Log(string message)
    {
        File.AppendAllText(_filePath, $"[LOG] {message}{Environment.NewLine}", Encoding.UTF8);
    }
}

internal sealed class NullLogger : ILogger
{
    public void Log(string message) { }
}

internal interface IBookStorage
{
    void Save(string title, string author);
    void Remove(string title);
}

internal sealed class InMemoryBookStorage : IBookStorage
{
    private readonly List<string> _books = new List<string>();
    private readonly ILogger _logger;

    public InMemoryBookStorage(ILogger logger)
    {
        _logger = logger;
    }

    public void Save(string title, string author)
    {
        _books.Add($"{title} — {author}");
        _logger.Log($"Книга сохранена в памяти: {title}");
    }

    public void Remove(string title)
    {
        for (int i = _books.Count - 1; i >= 0; i--)
        {
            if (_books[i].StartsWith(title + " —", StringComparison.Ordinal))
                _books.RemoveAt(i);
        }
        _logger.Log($"Запрошено удаление книги: {title}");
    }
}

internal sealed class BookCatalogService
{
    private readonly IBookStorage _storage;
    private readonly ILogger _logger;

    public BookCatalogService(IBookStorage storage, ILogger logger)
    {
        _storage = storage;
        _logger = logger;
    }

    public void AddBook(string title, string author)
    {
        _storage.Save(title, author);
        _logger.Log($"Добавлена книга: «{title}» — {author}");
    }

    public void RemoveBook(string title)
    {
        _storage.Remove(title);
        _logger.Log($"Удалена книга: «{title}»");
    }
}

internal sealed class BookCatalogServiceWithProperty
{
    public ILogger Logger { get; set; } = new NullLogger();

    public void AddBook(string title, string author)
    {
        Logger.Log($"Добавлена книга: «{title}» — {author}");
    }
}

internal sealed class BookCatalogServiceWithMethod
{
    public void AddBook(string title, string author, ILogger logger)
    {
        logger.Log($"Добавлена книга: «{title}» — {author}");
    }
}
