/*
Автор: Смыков В.А.
Домашнее задание №2. Вариант 20: проекты и задачи.
Запуск из папки проекта: dotnet run
*/

using System.Globalization;
using System.Text;

internal static class Program
{
    private const string StudentName = "Смыков В.А.";

    private static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.InputEncoding = Encoding.UTF8;
        CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;
        CultureInfo.CurrentUICulture = CultureInfo.InvariantCulture;

        Console.WriteLine("=== ДОМАШНЕЕ ЗАДАНИЕ №2. ВАРИАНТ 20: ПРОЕКТЫ И ЗАДАЧИ ===");
        Console.WriteLine($"Выполнил: {StudentName}");
        Console.WriteLine();

        string dbPath = Path.Combine(AppContext.BaseDirectory, "smykov_homework2_projects.db");
        string projectsCsv = Path.Combine(AppContext.BaseDirectory, "projects.csv");
        string tasksCsv = Path.Combine(AppContext.BaseDirectory, "project_tasks.csv");

        EnsureCsvFiles(projectsCsv, tasksCsv);
        DatabaseManager db = new DatabaseManager(dbPath);
        db.ImportFromCsv(projectsCsv, tasksCsv);

        string choice;
        do
        {
            Console.WriteLine("╔════════════════════════════════════════════╗");
            Console.WriteLine("║ УПРАВЛЕНИЕ ПРОЕКТАМИ И ЗАДАЧАМИ           ║");
            Console.WriteLine("╠════════════════════════════════════════════╣");
            Console.WriteLine("║ 1 — Показать все проекты                  ║");
            Console.WriteLine("║ 2 — Показать все задачи                   ║");
            Console.WriteLine("║ 3 — Добавить задачу                       ║");
            Console.WriteLine("║ 4 — Редактировать задачу                  ║");
            Console.WriteLine("║ 5 — Удалить задачу                        ║");
            Console.WriteLine("║ 6 — Отчёты                                ║");
            Console.WriteLine("║ 7 — Фильтр по проекту                     ║");
            Console.WriteLine("║ 0 — Выход                                 ║");
            Console.WriteLine("╚════════════════════════════════════════════╝");
            Console.Write("Ваш выбор: ");
            choice = Console.ReadLine()?.Trim() ?? string.Empty;
            Console.WriteLine();

            try
            {
                switch (choice)
                {
                    case "1": ShowProjects(db); break;
                    case "2": ShowProjectTasks(db); break;
                    case "3": AddProjectTask(db); break;
                    case "4": EditProjectTask(db); break;
                    case "5": DeleteProjectTask(db); break;
                    case "6": ReportsMenu(db); break;
                    case "7": FilterTasksByProject(db); break;
                    case "0": Console.WriteLine("Выход из домашнего задания."); break;
                    default: Console.WriteLine("Неверный пункт меню."); break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }

            Console.WriteLine();
        }
        while (choice != "0");
    }

    private static void EnsureCsvFiles(string projectsCsv, string tasksCsv)
    {
        File.WriteAllText(projectsCsv,
            "project_id;project_name\n" +
            "1;Интернет-магазин\n" +
            "2;Мобильное приложение\n" +
            "3;Корпоративный портал\n" +
            "4;Система аналитики\n", Encoding.UTF8);

        File.WriteAllText(tasksCsv,
            "task_id;project_id;task_name;hours\n" +
            "1;1;Проектирование каталога;18\n" +
            "2;1;Разработка корзины;26\n" +
            "3;1;Интеграция оплаты;34\n" +
            "4;2;Экран авторизации;12\n" +
            "5;2;Push-уведомления;16\n" +
            "6;2;Профиль пользователя;22\n" +
            "7;3;Модуль сотрудников;24\n" +
            "8;3;Согласование заявок;30\n" +
            "9;3;Импорт документов;20\n" +
            "10;4;Панель метрик;28\n" +
            "11;4;ETL-загрузка;36\n" +
            "12;4;Отчёты руководителя;32\n", Encoding.UTF8);
    }

    private static void ShowProjects(DatabaseManager db)
    {
        Console.WriteLine("=== Проекты ===");
        List<Project> projects = db.GetAllProjects();
        for (int i = 0; i < projects.Count; i++)
            Console.WriteLine(projects[i]);
    }

    private static void ShowProjectTasks(DatabaseManager db)
    {
        Console.WriteLine("=== Задачи ===");
        List<ProjectTask> tasks = db.GetAllTasks();
        for (int i = 0; i < tasks.Count; i++)
            Console.WriteLine(tasks[i]);
    }

    private static void AddProjectTask(DatabaseManager db)
    {
        Console.WriteLine("=== Добавление задачи ===");
        ShowProjects(db);
        int projectId = ReadInt("ID проекта: ");
        string name = ReadRequiredString("Название задачи: ");
        int hours = ReadNonNegativeInt("Трудоёмкость, человеко-часов: ");

        int nextId = db.GetNextTaskId();
        ProjectTask task = new ProjectTask(nextId, projectId, name, hours);
        db.AddTask(task);
        Console.WriteLine("Задача добавлена.");
    }

    private static void EditProjectTask(DatabaseManager db)
    {
        Console.WriteLine("=== Редактирование задачи ===");
        ShowProjectTasks(db);
        int id = ReadInt("ID задачи для редактирования: ");
        ProjectTask? current = db.GetTaskById(id);
        if (current == null)
        {
            Console.WriteLine("Задача не найдена.");
            return;
        }

        Console.WriteLine("Текущие значения:");
        Console.WriteLine(current);
        Console.WriteLine("Нажмите Enter без ввода, чтобы оставить поле без изменений.");

        ShowProjects(db);
        Console.Write($"ID проекта [{current.ProjectId}]: ");
        string projectText = Console.ReadLine()?.Trim() ?? string.Empty;
        int projectId = current.ProjectId;
        if (projectText.Length > 0 && !int.TryParse(projectText, NumberStyles.Integer, CultureInfo.InvariantCulture, out projectId))
        {
            Console.WriteLine("Ошибка: ID проекта должен быть целым числом.");
            return;
        }

        Console.Write($"Название задачи [{current.Name}]: ");
        string nameText = Console.ReadLine() ?? string.Empty;
        string name = string.IsNullOrWhiteSpace(nameText) ? current.Name : nameText.Trim();

        Console.Write($"Трудоёмкость [{current.Hours}]: ");
        string hoursText = Console.ReadLine()?.Trim() ?? string.Empty;
        int hours = current.Hours;
        if (hoursText.Length > 0 && !int.TryParse(hoursText, NumberStyles.Integer, CultureInfo.InvariantCulture, out hours))
        {
            Console.WriteLine("Ошибка: трудоёмкость должна быть целым числом.");
            return;
        }

        ProjectTask updated = new ProjectTask(id, projectId, name, hours);
        db.UpdateTask(updated);
        Console.WriteLine("Задача обновлена.");
    }

    private static void DeleteProjectTask(DatabaseManager db)
    {
        Console.WriteLine("=== Удаление задачи ===");
        ShowProjectTasks(db);
        int id = ReadInt("ID задачи для удаления: ");
        db.DeleteTask(id);
        Console.WriteLine("Задача удалена, если запись с таким ID существовала.");
    }

    private static void ReportsMenu(DatabaseManager db)
    {
        string choice;
        do
        {
            Console.WriteLine("╔════════════════════════════════════════════╗");
            Console.WriteLine("║ ОТЧЁТЫ                                     ║");
            Console.WriteLine("╠════════════════════════════════════════════╣");
            Console.WriteLine("║ 1 — Полный список задач по проектам        ║");
            Console.WriteLine("║ 2 — Количество задач в каждом проекте      ║");
            Console.WriteLine("║ 3 — Средняя трудоёмкость по проектам       ║");
            Console.WriteLine("║ 4 — Сохранить отчёт 1 в файл               ║");
            Console.WriteLine("║ 0 — Назад                                  ║");
            Console.WriteLine("╚════════════════════════════════════════════╝");
            Console.Write("Ваш выбор: ");
            choice = Console.ReadLine()?.Trim() ?? string.Empty;
            Console.WriteLine();

            switch (choice)
            {
                case "1": PrintReportFullTaskList(db); break;
                case "2": PrintReportTaskCountByProject(db); break;
                case "3": PrintReportAverageHoursByProject(db); break;
                case "4": SaveFullTaskReport(db); break;
                case "0": break;
                default: Console.WriteLine("Неверный пункт меню."); break;
            }

            Console.WriteLine();
        }
        while (choice != "0");
    }

    private static void PrintReportFullTaskList(DatabaseManager db)
    {
        new ReportBuilder(db)
            .Query(@"
                SELECT t.task_name AS task_name,
                       p.project_name AS project_name,
                       t.hours AS hours
                FROM project_task t
                JOIN project p ON t.project_id = p.project_id
                ORDER BY t.task_name;")
            .Title("Полный список задач по проектам")
            .Header("Задача", "Проект", "Часы")
            .ColumnWidths(30, 28, 10)
            .Numbered()
            .Footer("Всего задач")
            .Print();
    }

    private static void PrintReportTaskCountByProject(DatabaseManager db)
    {
        new ReportBuilder(db)
            .Query(@"
                SELECT p.project_name AS project_name,
                       COUNT(*) AS task_count
                FROM project_task t
                JOIN project p ON t.project_id = p.project_id
                GROUP BY p.project_name
                ORDER BY p.project_name;")
            .Title("Количество задач в каждом проекте")
            .Header("Проект", "Количество")
            .ColumnWidths(30, 15)
            .Numbered()
            .Print();
    }

    private static void PrintReportAverageHoursByProject(DatabaseManager db)
    {
        new ReportBuilder(db)
            .Query(@"
                SELECT p.project_name AS project_name,
                       ROUND(AVG(t.hours), 2) AS avg_hours
                FROM project_task t
                JOIN project p ON t.project_id = p.project_id
                GROUP BY p.project_name
                ORDER BY avg_hours DESC;")
            .Title("Средняя трудоёмкость по проектам")
            .Header("Проект", "Средние часы")
            .ColumnWidths(30, 15)
            .Numbered()
            .Print();
    }

    private static void SaveFullTaskReport(DatabaseManager db)
    {
        string path = Path.Combine(AppContext.BaseDirectory, "task_report.txt");
        new ReportBuilder(db)
            .Query(@"
                SELECT t.task_name AS task_name,
                       p.project_name AS project_name,
                       t.hours AS hours
                FROM project_task t
                JOIN project p ON t.project_id = p.project_id
                ORDER BY t.task_name;")
            .Title("Полный список задач по проектам")
            .Header("Задача", "Проект", "Часы")
            .ColumnWidths(30, 28, 10)
            .Numbered()
            .Footer("Всего задач")
            .SaveToFile(path);
    }

    private static void FilterTasksByProject(DatabaseManager db)
    {
        Console.WriteLine("=== Фильтр по проекту ===");
        ShowProjects(db);
        int projectId = ReadInt("ID проекта: ");
        List<ProjectTask> tasks = db.GetTasksByProject(projectId);
        Console.WriteLine($"Задачи проекта #{projectId}:");
        for (int i = 0; i < tasks.Count; i++)
            Console.WriteLine(tasks[i]);
        Console.WriteLine($"Найдено задач: {tasks.Count}");
    }

    private static int ReadInt(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            string text = Console.ReadLine()?.Trim() ?? string.Empty;
            if (int.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out int value))
                return value;
            Console.WriteLine("Ошибка: введите целое число.");
        }
    }

    private static int ReadNonNegativeInt(string prompt)
    {
        while (true)
        {
            int value = ReadInt(prompt);
            if (value >= 0)
                return value;
            Console.WriteLine("Ошибка: число не может быть отрицательным.");
        }
    }

    private static string ReadRequiredString(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            string text = Console.ReadLine() ?? string.Empty;
            if (!string.IsNullOrWhiteSpace(text))
                return text.Trim();
            Console.WriteLine("Ошибка: строка не должна быть пустой.");
        }
    }
}
