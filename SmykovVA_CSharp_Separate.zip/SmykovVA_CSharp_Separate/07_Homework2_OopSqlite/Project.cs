/// <summary>
/// Проект — справочная таблица варианта 20.
/// </summary>
internal sealed class Project
{
    /// <summary>
    /// Идентификатор проекта.
    /// </summary>
    public int Id { get; set; }

    /// <summary>
    /// Название проекта.
    /// </summary>
    public string Name { get; set; }

    /// <summary>
    /// Конструктор с параметрами.
    /// </summary>
    public Project(int id, string name)
    {
        Id = id;
        Name = name;
    }

    /// <summary>
    /// Конструктор по умолчанию.
    /// </summary>
    public Project() : this(0, string.Empty) { }

    public override string ToString()
    {
        return $"[{Id}] {Name}";
    }
}
