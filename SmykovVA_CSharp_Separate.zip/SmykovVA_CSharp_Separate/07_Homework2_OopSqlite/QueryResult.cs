/// <summary>
/// Табличный результат SQL-запроса.
/// </summary>
internal sealed class QueryResult
{
    public string[] Headers { get; }
    public List<string[]> Rows { get; }

    public QueryResult(string[] headers, List<string[]> rows)
    {
        Headers = headers;
        Rows = rows;
    }
}
