/// <summary>
/// Задача проекта — основная таблица варианта 20.
/// </summary>
internal sealed class ProjectTask
{
    private int _hours;

    /// <summary>
    /// Идентификатор задачи.
    /// </summary>
    public int Id { get; set; }

    /// <summary>
    /// Идентификатор проекта, к которому относится задача.
    /// </summary>
    public int ProjectId { get; set; }

    /// <summary>
    /// Название задачи.
    /// </summary>
    public string Name { get; set; }

    /// <summary>
    /// Трудоёмкость задачи в человеко-часах. Не может быть отрицательной.
    /// </summary>
    public int Hours
    {
        get { return _hours; }
        set
        {
            if (value < 0)
                throw new ArgumentException("Трудоёмкость не может быть отрицательной.");
            _hours = value;
        }
    }

    /// <summary>
    /// Конструктор с параметрами.
    /// </summary>
    public ProjectTask(int id, int projectId, string name, int hours)
    {
        Id = id;
        ProjectId = projectId;
        Name = name;
        Hours = hours;
    }

    /// <summary>
    /// Конструктор по умолчанию.
    /// </summary>
    public ProjectTask() : this(0, 0, string.Empty, 0) { }

    public override string ToString()
    {
        return $"[{Id}] {Name}, проект #{ProjectId}, трудоёмкость: {Hours} ч.";
    }
}
