using System.Globalization;
using System.Text;
using Microsoft.Data.Sqlite;

/// <summary>
/// Менеджер базы данных для домашнего задания №2.
/// </summary>
internal sealed class DatabaseManager
{
    private readonly string _dbPath;
    private readonly string _connectionString;

    /// <summary>
    /// Создаёт объект менеджера и при необходимости создаёт базу данных.
    /// </summary>
    public DatabaseManager(string dbPath)
    {
        _dbPath = dbPath;
        _connectionString = $"Data Source={_dbPath}";
        CreateTablesIfNeeded();
    }

    private void CreateTablesIfNeeded()
    {
        using SqliteConnection connection = new SqliteConnection(_connectionString);
        connection.Open();

        SqliteCommand command = connection.CreateCommand();
        command.CommandText = @"
            CREATE TABLE IF NOT EXISTS project (
                project_id INTEGER PRIMARY KEY,
                project_name TEXT NOT NULL
            );";
        command.ExecuteNonQuery();

        command.CommandText = @"
            CREATE TABLE IF NOT EXISTS project_task (
                task_id INTEGER PRIMARY KEY,
                project_id INTEGER NOT NULL,
                task_name TEXT NOT NULL,
                hours INTEGER NOT NULL CHECK(hours >= 0),
                FOREIGN KEY (project_id) REFERENCES project(project_id)
            );";
        command.ExecuteNonQuery();
    }

    /// <summary>
    /// Импортирует данные из двух CSV-файлов.
    /// </summary>
    public void ImportFromCsv(string projectsCsvPath, string tasksCsvPath)
    {
        using SqliteConnection connection = new SqliteConnection(_connectionString);
        connection.Open();

        SqliteCommand clearTasks = connection.CreateCommand();
        clearTasks.CommandText = "DELETE FROM project_task;";
        clearTasks.ExecuteNonQuery();
        SqliteCommand clearProjects = connection.CreateCommand();
        clearProjects.CommandText = "DELETE FROM project;";
        clearProjects.ExecuteNonQuery();

        using (SqliteTransaction transaction = connection.BeginTransaction())
        {
            string[] projectLines = File.ReadAllLines(projectsCsvPath, Encoding.UTF8);
            for (int i = 1; i < projectLines.Length; i++)
            {
                string[] parts = projectLines[i].Split(';');
                if (parts.Length < 2)
                    continue;

                SqliteCommand cmd = connection.CreateCommand();
                cmd.Transaction = transaction;
                cmd.CommandText = "INSERT INTO project (project_id, project_name) VALUES (@id, @name);";
                cmd.Parameters.AddWithValue("@id", int.Parse(parts[0], CultureInfo.InvariantCulture));
                cmd.Parameters.AddWithValue("@name", parts[1]);
                cmd.ExecuteNonQuery();
            }
            transaction.Commit();
        }

        using (SqliteTransaction transaction = connection.BeginTransaction())
        {
            string[] taskLines = File.ReadAllLines(tasksCsvPath, Encoding.UTF8);
            for (int i = 1; i < taskLines.Length; i++)
            {
                string[] parts = taskLines[i].Split(';');
                if (parts.Length < 4)
                    continue;

                SqliteCommand cmd = connection.CreateCommand();
                cmd.Transaction = transaction;
                cmd.CommandText = @"
                    INSERT INTO project_task (task_id, project_id, task_name, hours)
                    VALUES (@taskId, @projectId, @name, @hours);";
                cmd.Parameters.AddWithValue("@taskId", int.Parse(parts[0], CultureInfo.InvariantCulture));
                cmd.Parameters.AddWithValue("@projectId", int.Parse(parts[1], CultureInfo.InvariantCulture));
                cmd.Parameters.AddWithValue("@name", parts[2]);
                cmd.Parameters.AddWithValue("@hours", int.Parse(parts[3], CultureInfo.InvariantCulture));
                cmd.ExecuteNonQuery();
            }
            transaction.Commit();
        }

        Console.WriteLine("[OK] CSV-данные импортированы в SQLite.");
    }

    /// <summary>
    /// Возвращает список всех проектов.
    /// </summary>
    public List<Project> GetAllProjects()
    {
        List<Project> result = new List<Project>();
        using SqliteConnection connection = new SqliteConnection(_connectionString);
        connection.Open();
        SqliteCommand cmd = connection.CreateCommand();
        cmd.CommandText = "SELECT project_id, project_name FROM project ORDER BY project_id;";
        using SqliteDataReader reader = cmd.ExecuteReader();
        while (reader.Read())
            result.Add(new Project(reader.GetInt32(0), reader.GetString(1)));
        return result;
    }

    /// <summary>
    /// Возвращает список всех задач.
    /// </summary>
    public List<ProjectTask> GetAllTasks()
    {
        List<ProjectTask> result = new List<ProjectTask>();
        using SqliteConnection connection = new SqliteConnection(_connectionString);
        connection.Open();
        SqliteCommand cmd = connection.CreateCommand();
        cmd.CommandText = "SELECT task_id, project_id, task_name, hours FROM project_task ORDER BY task_id;";
        using SqliteDataReader reader = cmd.ExecuteReader();
        while (reader.Read())
            result.Add(new ProjectTask(reader.GetInt32(0), reader.GetInt32(1), reader.GetString(2), reader.GetInt32(3)));
        return result;
    }

    /// <summary>
    /// Возвращает задачу по идентификатору.
    /// </summary>
    public ProjectTask? GetTaskById(int id)
    {
        using SqliteConnection connection = new SqliteConnection(_connectionString);
        connection.Open();
        SqliteCommand cmd = connection.CreateCommand();
        cmd.CommandText = "SELECT task_id, project_id, task_name, hours FROM project_task WHERE task_id = @id;";
        cmd.Parameters.AddWithValue("@id", id);
        using SqliteDataReader reader = cmd.ExecuteReader();
        if (reader.Read())
            return new ProjectTask(reader.GetInt32(0), reader.GetInt32(1), reader.GetString(2), reader.GetInt32(3));
        return null;
    }

    /// <summary>
    /// Возвращает следующий идентификатор для новой задачи.
    /// </summary>
    public int GetNextTaskId()
    {
        using SqliteConnection connection = new SqliteConnection(_connectionString);
        connection.Open();
        SqliteCommand cmd = connection.CreateCommand();
        cmd.CommandText = "SELECT COALESCE(MAX(task_id), 0) + 1 FROM project_task;";
        object? value = cmd.ExecuteScalar();
        return Convert.ToInt32(value, CultureInfo.InvariantCulture);
    }

    /// <summary>
    /// Добавляет новую задачу.
    /// </summary>
    public void AddTask(ProjectTask task)
    {
        using SqliteConnection connection = new SqliteConnection(_connectionString);
        connection.Open();
        SqliteCommand cmd = connection.CreateCommand();
        cmd.CommandText = @"
            INSERT INTO project_task (task_id, project_id, task_name, hours)
            VALUES (@id, @projectId, @name, @hours);";
        cmd.Parameters.AddWithValue("@id", task.Id);
        cmd.Parameters.AddWithValue("@projectId", task.ProjectId);
        cmd.Parameters.AddWithValue("@name", task.Name);
        cmd.Parameters.AddWithValue("@hours", task.Hours);
        cmd.ExecuteNonQuery();
    }

    /// <summary>
    /// Обновляет существующую задачу по идентификатору.
    /// </summary>
    public void UpdateTask(ProjectTask task)
    {
        using SqliteConnection connection = new SqliteConnection(_connectionString);
        connection.Open();
        SqliteCommand cmd = connection.CreateCommand();
        cmd.CommandText = @"
            UPDATE project_task
            SET project_id = @projectId,
                task_name = @name,
                hours = @hours
            WHERE task_id = @id;";
        cmd.Parameters.AddWithValue("@id", task.Id);
        cmd.Parameters.AddWithValue("@projectId", task.ProjectId);
        cmd.Parameters.AddWithValue("@name", task.Name);
        cmd.Parameters.AddWithValue("@hours", task.Hours);
        cmd.ExecuteNonQuery();
    }

    /// <summary>
    /// Удаляет задачу по идентификатору.
    /// </summary>
    public void DeleteTask(int id)
    {
        using SqliteConnection connection = new SqliteConnection(_connectionString);
        connection.Open();
        SqliteCommand cmd = connection.CreateCommand();
        cmd.CommandText = "DELETE FROM project_task WHERE task_id = @id;";
        cmd.Parameters.AddWithValue("@id", id);
        cmd.ExecuteNonQuery();
    }

    /// <summary>
    /// Возвращает задачи выбранного проекта.
    /// </summary>
    public List<ProjectTask> GetTasksByProject(int projectId)
    {
        List<ProjectTask> result = new List<ProjectTask>();
        using SqliteConnection connection = new SqliteConnection(_connectionString);
        connection.Open();
        SqliteCommand cmd = connection.CreateCommand();
        cmd.CommandText = @"
            SELECT task_id, project_id, task_name, hours
            FROM project_task
            WHERE project_id = @projectId
            ORDER BY task_name;";
        cmd.Parameters.AddWithValue("@projectId", projectId);
        using SqliteDataReader reader = cmd.ExecuteReader();
        while (reader.Read())
            result.Add(new ProjectTask(reader.GetInt32(0), reader.GetInt32(1), reader.GetString(2), reader.GetInt32(3)));
        return result;
    }

    /// <summary>
    /// Выполняет SQL-запрос и возвращает табличный результат для ReportBuilder.
    /// </summary>
    public QueryResult ExecuteQuery(string sql)
    {
        using SqliteConnection connection = new SqliteConnection(_connectionString);
        connection.Open();
        SqliteCommand cmd = connection.CreateCommand();
        cmd.CommandText = sql;
        using SqliteDataReader reader = cmd.ExecuteReader();

        string[] headers = new string[reader.FieldCount];
        for (int c = 0; c < reader.FieldCount; c++)
            headers[c] = reader.GetName(c);

        List<string[]> rows = new List<string[]>();
        while (reader.Read())
        {
            string[] row = new string[reader.FieldCount];
            for (int c = 0; c < reader.FieldCount; c++)
                row[c] = Convert.ToString(reader.GetValue(c), CultureInfo.InvariantCulture) ?? string.Empty;
            rows.Add(row);
        }
        return new QueryResult(headers, rows);
    }
}
