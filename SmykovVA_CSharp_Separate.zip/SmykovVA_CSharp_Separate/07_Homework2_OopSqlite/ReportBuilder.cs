using System.Globalization;
using System.Text;

/// <summary>
/// Построитель отчётов с Fluent Interface.
/// </summary>
internal sealed class ReportBuilder
{
    private readonly DatabaseManager _db;
    private string _sql = string.Empty;
    private string _title = string.Empty;
    private string[] _headers = Array.Empty<string>();
    private int[] _widths = Array.Empty<int>();
    private bool _numbered;
    private string _footer = string.Empty;

    /// <summary>
    /// Конструктор принимает DatabaseManager для доступа к данным.
    /// </summary>
    public ReportBuilder(DatabaseManager db)
    {
        _db = db;
    }

    /// <summary>
    /// Задаёт SQL-запрос.
    /// </summary>
    public ReportBuilder Query(string sql)
    {
        _sql = sql;
        return this;
    }

    /// <summary>
    /// Задаёт заголовок отчёта.
    /// </summary>
    public ReportBuilder Title(string text)
    {
        _title = text;
        return this;
    }

    /// <summary>
    /// Задаёт названия колонок.
    /// </summary>
    public ReportBuilder Header(params string[] columns)
    {
        _headers = columns;
        return this;
    }

    /// <summary>
    /// Задаёт ширины колонок.
    /// </summary>
    public ReportBuilder ColumnWidths(params int[] widths)
    {
        _widths = widths;
        return this;
    }

    /// <summary>
    /// Добавляет нумерацию строк слева.
    /// </summary>
    public ReportBuilder Numbered()
    {
        _numbered = true;
        return this;
    }

    /// <summary>
    /// Добавляет итоговую строку в конец отчёта.
    /// </summary>
    public ReportBuilder Footer(string label)
    {
        _footer = label;
        return this;
    }

    /// <summary>
    /// Выполняет запрос и возвращает отформатированный отчёт.
    /// </summary>
    public string Build()
    {
        if (string.IsNullOrWhiteSpace(_sql))
            throw new InvalidOperationException("SQL-запрос не задан.");

        QueryResult table = _db.ExecuteQuery(_sql);
        string[] displayHeaders = _headers.Length > 0 ? _headers : table.Headers;
        int columnCount = displayHeaders.Length;
        int[] widths = new int[columnCount];
        for (int i = 0; i < columnCount; i++)
        {
            if (i < _widths.Length && _widths[i] > 0)
                widths[i] = _widths[i];
            else
                widths[i] = 15;
        }

        StringBuilder builder = new StringBuilder();
        if (!string.IsNullOrWhiteSpace(_title))
        {
            builder.AppendLine($"=== {_title} ===");
            builder.AppendLine();
        }

        int numberWidth = _numbered ? 5 : 0;
        if (_numbered)
            builder.Append("№".PadRight(numberWidth));

        for (int i = 0; i < columnCount; i++)
            builder.Append(displayHeaders[i].PadRight(widths[i]));
        builder.AppendLine();

        int totalWidth = numberWidth;
        for (int i = 0; i < columnCount; i++)
            totalWidth += widths[i];
        builder.AppendLine(new string('─', totalWidth));

        for (int r = 0; r < table.Rows.Count; r++)
        {
            if (_numbered)
                builder.Append((r + 1).ToString(CultureInfo.InvariantCulture).PadRight(numberWidth));

            for (int c = 0; c < columnCount; c++)
            {
                string value = c < table.Rows[r].Length ? table.Rows[r][c] : string.Empty;
                if (value.Length > widths[c] - 1 && widths[c] > 4)
                    value = value.Substring(0, widths[c] - 2) + "…";
                builder.Append(value.PadRight(widths[c]));
            }
            builder.AppendLine();
        }

        if (!string.IsNullOrWhiteSpace(_footer))
        {
            builder.AppendLine(new string('─', totalWidth));
            builder.AppendLine($"{_footer}: {table.Rows.Count}");
        }

        return builder.ToString();
    }

    /// <summary>
    /// Выводит отчёт в консоль.
    /// </summary>
    public void Print()
    {
        Console.Write(Build());
    }

    /// <summary>
    /// Сохраняет отчёт в текстовый файл.
    /// </summary>
    public void SaveToFile(string path)
    {
        File.WriteAllText(path, Build(), Encoding.UTF8);
        Console.WriteLine($"Отчёт сохранён в файл: {path}");
    }
}
