/*
Автор: Смыков В.А.
Семинар 3. Основы обработки CSV и работа с SQLite.
Запуск из папки проекта: dotnet run
*/

using System.Globalization;
using System.Text;
using Microsoft.Data.Sqlite;

internal static class Program
{
    private static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;
        CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;
        CultureInfo.CurrentUICulture = CultureInfo.InvariantCulture;

        Console.WriteLine("=== СЕМИНАР 3. CSV, SQLITE И РЕЛЯЦИОННЫЕ ОПЕРАЦИИ ===");

        string baseDir = AppContext.BaseDirectory;
        string dbPath = Path.Combine(baseDir, "seminar3_developers.db");
        string depCsvPath = Path.Combine(baseDir, "dep.csv");
        string devCsvPath = Path.Combine(baseDir, "dev.csv");

        CreateCsvFiles(depCsvPath, devCsvPath);
        CreateDatabase(dbPath);
        LoadData(dbPath, devCsvPath, depCsvPath);

        PrintTable(dbPath, "dep");
        PrintTable(dbPath, "dev");

        List<string> names = Projection(dbPath, "dev", "dev_name");
        Console.WriteLine("\n=== Результат Projection(dev, dev_name) ===");
        for (int i = 0; i < names.Count; i++)
            Console.WriteLine(names[i]);

        List<string[]> rows = Where(dbPath, "dev", "dep_id", "2");
        Console.WriteLine("\n=== Результат Where(dev, dep_id, 2) ===");
        for (int i = 0; i < rows.Count; i++)
            Console.WriteLine(string.Join(" | ", rows[i]));

        QueryResult join = Join(dbPath, "dev", "dep", "dep_id", "dep_id");
        PrintQueryResult("=== Результат Join(dev, dep, dep_id, dep_id) ===", join, 18);

        QueryResult groupAvg = GroupAvg(dbPath, "dev", "dep_id", "dev_commits");
        PrintQueryResult("=== Результат GroupAvg(dev, dep_id, dev_commits) ===", groupAvg, 18);

        Console.WriteLine("\n=== Пример реляционных операций на CSV без SQLite ===");
        using StringReader reader = new StringReader(File.ReadAllText(devCsvPath, Encoding.UTF8));
        QueryResult csvTable = ReadCsv(reader, ';');
        PrintQueryResult("Projection CSV(dev, dev_name)", CsvProjection(csvTable, "dev_name"), 18);
        PrintQueryResult("Where CSV(dev, dep_id = 2)", CsvWhere(csvTable, "dep_id", "2"), 18);
    }

    private static void CreateCsvFiles(string depCsvPath, string devCsvPath)
    {
        File.WriteAllText(depCsvPath,
            "dep_id;dep_name\n" +
            "1;Отдел C++\n" +
            "2;Отдел C#\n" +
            "3;Отдел Python\n", Encoding.UTF8);

        File.WriteAllText(devCsvPath,
            "dev_id;dep_id;dev_name;dev_commits\n" +
            "1;1;Иванов И.И.;3\n" +
            "2;1;Петров П.П.;5\n" +
            "3;1;Сидоров С.С.;8\n" +
            "4;2;Коломин К.К.;30\n" +
            "5;2;Суздальцев С.С.;50\n" +
            "6;2;Рязанцев Р.Р.;80\n" +
            "7;3;Волгин В.В.;300\n" +
            "8;3;Енисеев Е.Е.;500\n" +
            "9;3;Иртышев И.И.;800\n", Encoding.UTF8);
    }

    private static void CreateDatabase(string dbPath)
    {
        if (File.Exists(dbPath))
            File.Delete(dbPath);

        using SqliteConnection connection = new SqliteConnection($"Data Source={dbPath}");
        connection.Open();

        SqliteCommand command = connection.CreateCommand();
        command.CommandText = @"
            CREATE TABLE dep (
                dep_id INTEGER PRIMARY KEY,
                dep_name TEXT NOT NULL
            );";
        command.ExecuteNonQuery();

        command.CommandText = @"
            CREATE TABLE dev (
                dev_id INTEGER PRIMARY KEY,
                dep_id INTEGER NOT NULL,
                dev_name TEXT NOT NULL,
                dev_commits INTEGER NOT NULL,
                FOREIGN KEY (dep_id) REFERENCES dep(dep_id)
            );";
        command.ExecuteNonQuery();

        Console.WriteLine($"[OK] База данных '{Path.GetFileName(dbPath)}' создана.");
    }

    private static void LoadData(string dbPath, string devCsvPath, string depCsvPath)
    {
        using SqliteConnection connection = new SqliteConnection($"Data Source={dbPath}");
        connection.Open();

        using (SqliteTransaction transaction = connection.BeginTransaction())
        {
            string[] lines = File.ReadAllLines(depCsvPath, Encoding.UTF8);
            for (int i = 1; i < lines.Length; i++)
            {
                string[] parts = lines[i].Split(';');
                if (parts.Length < 2)
                    continue;

                SqliteCommand cmd = connection.CreateCommand();
                cmd.Transaction = transaction;
                cmd.CommandText = "INSERT INTO dep (dep_id, dep_name) VALUES (@id, @name);";
                cmd.Parameters.AddWithValue("@id", int.Parse(parts[0], CultureInfo.InvariantCulture));
                cmd.Parameters.AddWithValue("@name", parts[1]);
                cmd.ExecuteNonQuery();
            }
            transaction.Commit();
            Console.WriteLine($"[OK] Загружено строк из dep.csv: {lines.Length - 1}");
        }

        using (SqliteTransaction transaction = connection.BeginTransaction())
        {
            string[] lines = File.ReadAllLines(devCsvPath, Encoding.UTF8);
            for (int i = 1; i < lines.Length; i++)
            {
                string[] parts = lines[i].Split(';');
                if (parts.Length < 4)
                    continue;

                SqliteCommand cmd = connection.CreateCommand();
                cmd.Transaction = transaction;
                cmd.CommandText = @"
                    INSERT INTO dev (dev_id, dep_id, dev_name, dev_commits)
                    VALUES (@devId, @depId, @name, @commits);";
                cmd.Parameters.AddWithValue("@devId", int.Parse(parts[0], CultureInfo.InvariantCulture));
                cmd.Parameters.AddWithValue("@depId", int.Parse(parts[1], CultureInfo.InvariantCulture));
                cmd.Parameters.AddWithValue("@name", parts[2]);
                cmd.Parameters.AddWithValue("@commits", int.Parse(parts[3], CultureInfo.InvariantCulture));
                cmd.ExecuteNonQuery();
            }
            transaction.Commit();
            Console.WriteLine($"[OK] Загружено строк из dev.csv: {lines.Length - 1}");
        }
    }

    private static void PrintTable(string dbPath, string tableName)
    {
        using SqliteConnection connection = new SqliteConnection($"Data Source={dbPath}");
        connection.Open();
        SqliteCommand cmd = connection.CreateCommand();
        cmd.CommandText = $"SELECT * FROM {tableName} ORDER BY 1;";
        using SqliteDataReader reader = cmd.ExecuteReader();

        int columnCount = reader.FieldCount;
        const int width = 20;
        Console.WriteLine($"\n========== Таблица {tableName} ==========");
        for (int c = 0; c < columnCount; c++)
            Console.Write($"{reader.GetName(c),-width}");
        Console.WriteLine();
        Console.WriteLine(new string('-', width * columnCount));

        while (reader.Read())
        {
            for (int c = 0; c < columnCount; c++)
                Console.Write($"{reader.GetValue(c),-width}");
            Console.WriteLine();
        }
    }

    private static List<string> Projection(string dbPath, string tableName, string columnName)
    {
        List<string> result = new List<string>();
        using SqliteConnection connection = new SqliteConnection($"Data Source={dbPath}");
        connection.Open();
        SqliteCommand cmd = connection.CreateCommand();
        cmd.CommandText = $"SELECT {columnName} FROM {tableName} ORDER BY 1;";
        using SqliteDataReader reader = cmd.ExecuteReader();
        while (reader.Read())
            result.Add(Convert.ToString(reader.GetValue(0), CultureInfo.InvariantCulture) ?? string.Empty);
        return result;
    }

    private static List<string[]> Where(string dbPath, string tableName, string columnName, string value)
    {
        List<string[]> result = new List<string[]>();
        using SqliteConnection connection = new SqliteConnection($"Data Source={dbPath}");
        connection.Open();
        SqliteCommand cmd = connection.CreateCommand();
        cmd.CommandText = $"SELECT * FROM {tableName} WHERE {columnName} = @value ORDER BY 1;";
        cmd.Parameters.AddWithValue("@value", value);
        using SqliteDataReader reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            string[] row = new string[reader.FieldCount];
            for (int c = 0; c < reader.FieldCount; c++)
                row[c] = Convert.ToString(reader.GetValue(c), CultureInfo.InvariantCulture) ?? string.Empty;
            result.Add(row);
        }
        return result;
    }

    private static QueryResult Join(string dbPath, string table1, string table2, string key1, string key2)
    {
        using SqliteConnection connection = new SqliteConnection($"Data Source={dbPath}");
        connection.Open();
        SqliteCommand cmd = connection.CreateCommand();
        cmd.CommandText = $@"
            SELECT *
            FROM {table1}
            INNER JOIN {table2}
            ON {table1}.{key1} = {table2}.{key2}
            ORDER BY 1;";
        return ExecuteReaderToQueryResult(cmd.ExecuteReader());
    }

    private static QueryResult GroupAvg(string dbPath, string tableName, string groupColumn, string avgColumn)
    {
        using SqliteConnection connection = new SqliteConnection($"Data Source={dbPath}");
        connection.Open();
        SqliteCommand cmd = connection.CreateCommand();
        cmd.CommandText = $@"
            SELECT {groupColumn}, ROUND(AVG({avgColumn}), 2) AS avg_{avgColumn}
            FROM {tableName}
            GROUP BY {groupColumn}
            ORDER BY 1;";
        return ExecuteReaderToQueryResult(cmd.ExecuteReader());
    }

    private static QueryResult ExecuteReaderToQueryResult(SqliteDataReader reader)
    {
        using (reader)
        {
            string[] headers = new string[reader.FieldCount];
            for (int c = 0; c < reader.FieldCount; c++)
                headers[c] = reader.GetName(c);

            List<string[]> rows = new List<string[]>();
            while (reader.Read())
            {
                string[] row = new string[reader.FieldCount];
                for (int c = 0; c < reader.FieldCount; c++)
                    row[c] = Convert.ToString(reader.GetValue(c), CultureInfo.InvariantCulture) ?? string.Empty;
                rows.Add(row);
            }
            return new QueryResult(headers, rows);
        }
    }

    private static QueryResult ReadCsv(TextReader reader, char separator)
    {
        string? headerLine = reader.ReadLine();
        if (headerLine == null)
            return new QueryResult(Array.Empty<string>(), new List<string[]>());

        string[] headers = headerLine.Split(separator);
        List<string[]> rows = new List<string[]>();
        string? line;
        while ((line = reader.ReadLine()) != null)
        {
            if (line.Length > 0)
                rows.Add(line.Split(separator));
        }
        return new QueryResult(headers, rows);
    }

    private static QueryResult CsvProjection(QueryResult table, string columnName)
    {
        int columnIndex = FindColumnIndex(table.Headers, columnName);
        if (columnIndex < 0)
            throw new ArgumentException($"Колонка '{columnName}' не найдена.");

        List<string[]> rows = new List<string[]>();
        for (int r = 0; r < table.Rows.Count; r++)
            rows.Add(new[] { table.Rows[r][columnIndex] });
        return new QueryResult(new[] { columnName }, rows);
    }

    private static QueryResult CsvWhere(QueryResult table, string columnName, string value)
    {
        int columnIndex = FindColumnIndex(table.Headers, columnName);
        if (columnIndex < 0)
            throw new ArgumentException($"Колонка '{columnName}' не найдена.");

        List<string[]> rows = new List<string[]>();
        for (int r = 0; r < table.Rows.Count; r++)
        {
            if (table.Rows[r][columnIndex] == value)
            {
                string[] copied = new string[table.Rows[r].Length];
                Array.Copy(table.Rows[r], copied, table.Rows[r].Length);
                rows.Add(copied);
            }
        }
        return new QueryResult(table.Headers, rows);
    }

    private static int FindColumnIndex(string[] headers, string columnName)
    {
        for (int i = 0; i < headers.Length; i++)
        {
            if (string.Equals(headers[i], columnName, StringComparison.OrdinalIgnoreCase))
                return i;
        }
        return -1;
    }

    private static void PrintQueryResult(string title, QueryResult table, int width)
    {
        Console.WriteLine();
        Console.WriteLine(title);
        for (int i = 0; i < table.Headers.Length; i++)
            Console.Write(table.Headers[i].PadRight(width));
        Console.WriteLine();
        Console.WriteLine(new string('-', width * table.Headers.Length));
        for (int r = 0; r < table.Rows.Count; r++)
        {
            for (int c = 0; c < table.Rows[r].Length; c++)
                Console.Write(table.Rows[r][c].PadRight(width));
            Console.WriteLine();
        }
    }
}

internal sealed class QueryResult
{
    public string[] Headers { get; }
    public List<string[]> Rows { get; }

    public QueryResult(string[] headers, List<string[]> rows)
    {
        Headers = headers;
        Rows = rows;
    }
}
