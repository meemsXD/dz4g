/*
Автор: Смыков В.А.
Семинар 2. Работа с разреженными матрицами: COO, LIL, CSR.
Запуск из папки проекта: dotnet run
*/

using System.Text;

internal static class Program
{
    private static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;

        Console.WriteLine("=== СЕМИНАР 2. РАЗРЕЖЕННЫЕ МАТРИЦЫ ===");

        int[,] matrixCoo =
        {
            { 0, 0, 9, 0, 0, 0 },
            { 0, 2, 0, 0, 0, 0 },
            { 0, 0, 0, 1, 0, 0 },
            { 0, 0, 0, 0, 5, 0 },
            { 0, 0, 0, 6, 0, 0 }
        };

        int[,] matrixLil =
        {
            {  8, 0, 1, 0, -1 },
            {  0, 8, 2, 0,  0 },
            {  0, 0, 3, 0,  0 },
            { -2, 0, 4, 8, -2 },
            {  0, 0, 5, 0,  8 },
            {  0, 0, 6, 0,  0 }
        };

        int[,] matrixCsr =
        {
            { 8, 0, 2, 0, 0 },
            { 0, 0, 5, 0, 0 },
            { 0, 0, 0, 0, 0 },
            { 0, 0, 0, 0, 0 },
            { 0, 0, 7, 1, 2 },
            { 0, 0, 0, 0, 0 },
            { 0, 0, 0, 9, 0 }
        };

        Console.WriteLine();
        RunCooDemo(matrixCoo);
        Console.WriteLine();
        RunLilDemo(matrixLil);
        Console.WriteLine();
        RunCsrDemo(matrixCsr);
    }

    private static void RunCooDemo(int[,] matrix)
    {
        Console.WriteLine("--- Задание 1. COO ---");
        Console.WriteLine("Порог эффективности COO: 3 * N < R * C, где N — количество ненулевых элементов.");
        PrintMatrix("Плотная матрица:", matrix);
        DenseToCOO(matrix, out int[] row, out int[] column, out int[] data);
        PrintIntArray("Row", row);
        PrintIntArray("Column", column);
        PrintIntArray("Data", data);
        int[,] restored = COOToDense(row, column, data, matrix.GetLength(0), matrix.GetLength(1));
        PrintMatrix("Восстановленная матрица:", restored);
        Console.WriteLine($"COO эффективен: {IsCOOEffective(matrix)}");
        Console.WriteLine($"Проверка восстановления: {(MatricesAreEqual(matrix, restored) ? "OK" : "Ошибка")}");
    }

    private static void RunLilDemo(int[,] matrix)
    {
        Console.WriteLine("--- Задание 2. LIL ---");
        Console.WriteLine("Порог эффективности LIL: 2 * N < R * C, где N — количество ненулевых элементов.");
        PrintMatrix("Плотная матрица:", matrix);
        DenseToLIL(matrix, out int[][] rows, out int[][] data);
        PrintJaggedArray("Rows", rows);
        PrintJaggedArray("Data", data);
        int[,] restored = LILToDense(rows, data, matrix.GetLength(0), matrix.GetLength(1));
        PrintMatrix("Восстановленная матрица:", restored);
        Console.WriteLine($"LIL эффективен: {IsLILEffective(matrix)}");
        Console.WriteLine($"Проверка восстановления: {(MatricesAreEqual(matrix, restored) ? "OK" : "Ошибка")}");
    }

    private static void RunCsrDemo(int[,] matrix)
    {
        Console.WriteLine("--- Задание 3. CSR ---");
        Console.WriteLine("Порог эффективности CSR: 2 * N + R + 1 < R * C.");
        PrintMatrix("Плотная матрица:", matrix);
        DenseToCSR(matrix, out int[] data, out int[] indices, out int[] indexPointers);
        PrintIntArray("Data", data);
        PrintIntArray("Indices", indices);
        PrintIntArray("Index Pointers", indexPointers);
        int[,] restored = CSRToDense(data, indices, indexPointers, matrix.GetLength(0), matrix.GetLength(1));
        PrintMatrix("Восстановленная матрица:", restored);
        Console.WriteLine($"CSR эффективен: {IsCSREffective(matrix)}");
        Console.WriteLine($"Проверка восстановления: {(MatricesAreEqual(matrix, restored) ? "OK" : "Ошибка")}");
    }

    private static void DenseToCOO(int[,] matrix, out int[] row, out int[] column, out int[] data)
    {
        int nonZero = CountNonZero(matrix);
        row = new int[nonZero];
        column = new int[nonZero];
        data = new int[nonZero];

        int index = 0;
        for (int r = 0; r < matrix.GetLength(0); r++)
        {
            for (int c = 0; c < matrix.GetLength(1); c++)
            {
                if (matrix[r, c] != 0)
                {
                    row[index] = r;
                    column[index] = c;
                    data[index] = matrix[r, c];
                    index++;
                }
            }
        }
    }

    private static int[,] COOToDense(int[] row, int[] column, int[] data, int rowCount, int columnCount)
    {
        int[,] matrix = new int[rowCount, columnCount];
        for (int i = 0; i < data.Length; i++)
            matrix[row[i], column[i]] = data[i];
        return matrix;
    }

    private static bool IsCOOEffective(int[,] matrix)
    {
        int cellsDense = matrix.GetLength(0) * matrix.GetLength(1);
        int cellsSparse = CountNonZero(matrix) * 3;
        return cellsSparse < cellsDense;
    }

    private static void DenseToLIL(int[,] matrix, out int[][] rows, out int[][] data)
    {
        int rowCount = matrix.GetLength(0);
        int columnCount = matrix.GetLength(1);
        rows = new int[rowCount][];
        data = new int[rowCount][];

        for (int r = 0; r < rowCount; r++)
        {
            int count = 0;
            for (int c = 0; c < columnCount; c++)
            {
                if (matrix[r, c] != 0)
                    count++;
            }

            rows[r] = new int[count];
            data[r] = new int[count];

            int index = 0;
            for (int c = 0; c < columnCount; c++)
            {
                if (matrix[r, c] != 0)
                {
                    rows[r][index] = c;
                    data[r][index] = matrix[r, c];
                    index++;
                }
            }
        }
    }

    private static int[,] LILToDense(int[][] rows, int[][] data, int rowCount, int columnCount)
    {
        int[,] matrix = new int[rowCount, columnCount];
        for (int r = 0; r < rowCount; r++)
        {
            for (int i = 0; i < rows[r].Length; i++)
                matrix[r, rows[r][i]] = data[r][i];
        }
        return matrix;
    }

    private static bool IsLILEffective(int[,] matrix)
    {
        int cellsDense = matrix.GetLength(0) * matrix.GetLength(1);
        int cellsSparse = CountNonZero(matrix) * 2;
        return cellsSparse < cellsDense;
    }

    private static void DenseToCSR(int[,] matrix, out int[] data, out int[] indices, out int[] indexPointers)
    {
        List<int> dataList = new List<int>();
        List<int> indexList = new List<int>();
        int rowCount = matrix.GetLength(0);
        int columnCount = matrix.GetLength(1);
        indexPointers = new int[rowCount + 1];

        int nonZeroBeforeRow = 0;
        indexPointers[0] = 0;
        for (int r = 0; r < rowCount; r++)
        {
            for (int c = 0; c < columnCount; c++)
            {
                if (matrix[r, c] != 0)
                {
                    dataList.Add(matrix[r, c]);
                    indexList.Add(c);
                    nonZeroBeforeRow++;
                }
            }
            indexPointers[r + 1] = nonZeroBeforeRow;
        }

        data = dataList.ToArray();
        indices = indexList.ToArray();
    }

    private static int[,] CSRToDense(int[] data, int[] indices, int[] indexPointers, int rowCount, int columnCount)
    {
        int[,] matrix = new int[rowCount, columnCount];
        for (int r = 0; r < rowCount; r++)
        {
            int start = indexPointers[r];
            int end = indexPointers[r + 1];
            for (int i = start; i < end; i++)
                matrix[r, indices[i]] = data[i];
        }
        return matrix;
    }

    private static bool IsCSREffective(int[,] matrix)
    {
        int rowCount = matrix.GetLength(0);
        int columnCount = matrix.GetLength(1);
        int nonZero = CountNonZero(matrix);
        int cellsDense = rowCount * columnCount;
        int cellsSparse = nonZero * 2 + rowCount + 1;
        return cellsSparse < cellsDense;
    }

    private static int CountNonZero(int[,] matrix)
    {
        int count = 0;
        for (int r = 0; r < matrix.GetLength(0); r++)
        {
            for (int c = 0; c < matrix.GetLength(1); c++)
            {
                if (matrix[r, c] != 0)
                    count++;
            }
        }
        return count;
    }

    private static bool MatricesAreEqual(int[,] first, int[,] second)
    {
        if (first.GetLength(0) != second.GetLength(0) || first.GetLength(1) != second.GetLength(1))
            return false;

        for (int r = 0; r < first.GetLength(0); r++)
        {
            for (int c = 0; c < first.GetLength(1); c++)
            {
                if (first[r, c] != second[r, c])
                    return false;
            }
        }
        return true;
    }

    private static void PrintMatrix(string title, int[,] matrix)
    {
        Console.WriteLine(title);
        for (int r = 0; r < matrix.GetLength(0); r++)
        {
            for (int c = 0; c < matrix.GetLength(1); c++)
                Console.Write($"{matrix[r, c],5}");
            Console.WriteLine();
        }
    }

    private static void PrintIntArray(string title, int[] values)
    {
        Console.WriteLine(title + ": " + string.Join(", ", values));
    }

    private static void PrintJaggedArray(string title, int[][] values)
    {
        Console.WriteLine(title + ":");
        for (int i = 0; i < values.Length; i++)
            Console.WriteLine($"  [{i}] {string.Join(", ", values[i])}");
    }
}
