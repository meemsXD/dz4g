/// <summary>
/// Абстрактная геометрическая фигура.
/// </summary>
internal abstract class Figure : IComparable
{
    public string Type { get; }
    public abstract double Area { get; }

    protected Figure(string type)
    {
        Type = type;
    }

    public override string ToString()
    {
        return $"{Type} площадью {Area:F2}";
    }

    public int CompareTo(object? obj)
    {
        if (obj is Figure other)
            return Area.CompareTo(other.Area);
        throw new ArgumentException("Объект не является фигурой.");
    }
}
