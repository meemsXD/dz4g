/*
Автор: Смыков В.А.
Семинар 4. Создание классов и коллекций.
Запуск из папки проекта: dotnet run
*/

using System.Text;

internal static class Program
{
    private static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;

        Console.WriteLine("=== СЕМИНАР 4. СОЗДАНИЕ КЛАССОВ И КОЛЛЕКЦИЙ ===");

        RectangleFigure rect = new RectangleFigure(5, 4);
        Square square = new Square(5);
        Circle circle = new Circle(5);

        Console.WriteLine("\nГеометрические фигуры:");
        Console.WriteLine(rect);
        Console.WriteLine(square);
        Console.WriteLine(circle);

        Console.WriteLine("\nРазреженная матрица фигур:");
        SparseMatrix<Figure> matrix = new SparseMatrix<Figure>(3, 3, new FigureMatrixCheckEmpty());
        matrix[0, 0] = rect;
        matrix[1, 1] = square;
        matrix[2, 2] = circle;
        Console.WriteLine(matrix);

        Console.WriteLine("Перед сортировкой списка:");
        SimpleList<Figure> list = new SimpleList<Figure>();
        list.Add(circle);
        list.Add(rect);
        list.Add(square);
        foreach (Figure figure in list)
            Console.WriteLine(figure);

        list.Sort();
        Console.WriteLine("\nПосле сортировки списка:");
        foreach (Figure figure in list)
            Console.WriteLine(figure);

        SimpleStack<Figure> stack = new SimpleStack<Figure>();
        stack.Push(rect);
        stack.Push(square);
        stack.Push(circle);
        Console.WriteLine("\nВывод данных стека:");
        while (stack.Count > 0)
            Console.WriteLine(stack.Pop());
    }
}
