using System.Collections;

/// <summary>
/// Простой односвязный список с сортировкой.
/// </summary>
internal class SimpleList<T> : IEnumerable<T> where T : IComparable
{
    protected SimpleListItem<T>? first;
    protected SimpleListItem<T>? last;

    public int Count { get; protected set; }

    public void Add(T element)
    {
        SimpleListItem<T> item = new SimpleListItem<T>(element);
        if (first == null)
        {
            first = item;
            last = item;
        }
        else
        {
            last!.Next = item;
            last = item;
        }
        Count++;
    }

    protected SimpleListItem<T> GetItem(int index)
    {
        if (index < 0 || index >= Count)
            throw new ArgumentOutOfRangeException(nameof(index));

        SimpleListItem<T> current = first!;
        for (int i = 0; i < index; i++)
            current = current.Next!;
        return current;
    }

    public T this[int index]
    {
        get { return GetItem(index).Data; }
        set { GetItem(index).Data = value; }
    }

    public void Sort()
    {
        if (Count > 1)
            Sort(0, Count - 1);
    }

    private void Sort(int low, int high)
    {
        int i = low;
        int j = high;
        T pivot = this[(low + high) / 2];

        while (i <= j)
        {
            while (this[i].CompareTo(pivot) < 0)
                i++;
            while (this[j].CompareTo(pivot) > 0)
                j--;

            if (i <= j)
            {
                Swap(i, j);
                i++;
                j--;
            }
        }

        if (low < j)
            Sort(low, j);
        if (i < high)
            Sort(i, high);
    }

    private void Swap(int firstIndex, int secondIndex)
    {
        if (firstIndex == secondIndex)
            return;

        SimpleListItem<T> firstItem = GetItem(firstIndex);
        SimpleListItem<T> secondItem = GetItem(secondIndex);
        T temp = firstItem.Data;
        firstItem.Data = secondItem.Data;
        secondItem.Data = temp;
    }

    public IEnumerator<T> GetEnumerator()
    {
        SimpleListItem<T>? current = first;
        while (current != null)
        {
            yield return current.Data;
            current = current.Next;
        }
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
        return GetEnumerator();
    }
}
