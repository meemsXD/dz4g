/// <summary>
/// Элемент односвязного списка.
/// </summary>
internal sealed class SimpleListItem<T>
{
    public T Data { get; set; }
    public SimpleListItem<T>? Next { get; set; }

    public SimpleListItem(T data)
    {
        Data = data;
    }
}
