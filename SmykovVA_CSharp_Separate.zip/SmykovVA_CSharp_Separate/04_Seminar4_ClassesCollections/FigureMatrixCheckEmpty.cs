/// <summary>
/// Проверка пустого значения для фигур.
/// </summary>
internal sealed class FigureMatrixCheckEmpty : IMatrixCheckEmpty<Figure>
{
    public Figure GetEmptyElement()
    {
        return null!;
    }

    public bool CheckEmptyElement(Figure element)
    {
        return element is null;
    }
}
