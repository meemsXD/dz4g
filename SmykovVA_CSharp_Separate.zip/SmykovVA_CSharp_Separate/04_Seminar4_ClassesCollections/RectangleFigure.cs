/// <summary>
/// Прямоугольник.
/// </summary>
internal class RectangleFigure : Figure
{
    private readonly double _height;
    private readonly double _width;

    public RectangleFigure(double height, double width, string type = "Прямоугольник") : base(type)
    {
        _height = height;
        _width = width;
    }

    public override double Area => _height * _width;
}
