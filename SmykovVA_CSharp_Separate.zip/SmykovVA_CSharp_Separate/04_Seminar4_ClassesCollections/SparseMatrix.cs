using System.Text;

/// <summary>
/// Разреженная матрица на основе словаря.
/// </summary>
internal sealed class SparseMatrix<T>
{
    private readonly int _maxX;
    private readonly int _maxY;
    private readonly IMatrixCheckEmpty<T> _checkEmpty;
    private readonly Dictionary<(int x, int y), T> _matrix = new Dictionary<(int x, int y), T>();

    public int ColumnWidth { get; set; } = 32;

    public SparseMatrix(int maxX, int maxY, IMatrixCheckEmpty<T> checkEmpty)
    {
        _maxX = maxX;
        _maxY = maxY;
        _checkEmpty = checkEmpty;
    }

    public T this[int x, int y]
    {
        get
        {
            CheckBounds(x, y);
            if (_matrix.TryGetValue((x, y), out T? element))
                return element;
            return _checkEmpty.GetEmptyElement();
        }
        set
        {
            CheckBounds(x, y);
            _matrix[(x, y)] = value;
        }
    }

    private void CheckBounds(int x, int y)
    {
        if (x < 0 || x >= _maxX)
            throw new ArgumentOutOfRangeException(nameof(x), $"x={x} выходит за границы");
        if (y < 0 || y >= _maxY)
            throw new ArgumentOutOfRangeException(nameof(y), $"y={y} выходит за границы");
    }

    public override string ToString()
    {
        StringBuilder builder = new StringBuilder();
        for (int y = 0; y < _maxY; y++)
        {
            builder.Append('|');
            for (int x = 0; x < _maxX; x++)
            {
                T element = this[x, y];
                string cell = !_checkEmpty.CheckEmptyElement(element) ? $"{element}" : "-";
                builder.Append(cell.PadRight(ColumnWidth));
                builder.Append('|');
            }
            builder.AppendLine();
        }
        return builder.ToString();
    }
}
