/// <summary>
/// Квадрат.
/// </summary>
internal sealed class Square : RectangleFigure
{
    public Square(double size) : base(size, size, "Квадрат") { }
}
