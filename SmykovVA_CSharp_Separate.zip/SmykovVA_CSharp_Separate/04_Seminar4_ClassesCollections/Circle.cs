/// <summary>
/// Круг.
/// </summary>
internal sealed class Circle : Figure
{
    private readonly double _radius;

    public Circle(double radius) : base("Круг")
    {
        _radius = radius;
    }

    public override double Area => Math.PI * _radius * _radius;
}
