/// <summary>
/// Интерфейс для проверки пустого элемента матрицы.
/// </summary>
internal interface IMatrixCheckEmpty<T>
{
    T GetEmptyElement();
    bool CheckEmptyElement(T element);
}
