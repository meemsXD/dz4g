/// <summary>
/// Стек на основе простого списка.
/// </summary>
internal sealed class SimpleStack<T> : SimpleList<T> where T : IComparable
{
    public void Push(T element)
    {
        Add(element);
    }

    public T Pop()
    {
        if (Count == 0)
            return default!;

        T result;
        if (Count == 1)
        {
            result = first!.Data;
            first = null;
            last = null;
            Count = 0;
            return result;
        }

        SimpleListItem<T> newLast = GetItem(Count - 2);
        result = newLast.Next!.Data;
        newLast.Next = null;
        last = newLast;
        Count--;
        return result;
    }
}
